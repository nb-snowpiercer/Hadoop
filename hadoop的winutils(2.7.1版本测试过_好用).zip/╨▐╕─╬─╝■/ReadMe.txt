将bin目录和etc目录覆盖到hadoop的bin目录和etc目录，
然后修改etc/hadoop/hdfs-site.xml文件，

1、如果是安装在虚拟机上，将etc/hadoop/hdfs-site.xml文件修改为

<configuration>
 <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>/C:/hadoop/workplace/data/namenode</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>/C:/hadoop/workplace/data/datanode</value>
    </property>
</configuration>

2、如果是安装在本地机上，将etc/hadoop/hdfs-site.xml文件修改为

<configuration>
 <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>/D:/hadoop/workplace/data/namenode</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>/D:/hadoop/workplace/data/datanode</value>
    </property>
</configuration>